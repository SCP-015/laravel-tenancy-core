const s="/build/assets/copy-vU9nRUmU.svg";export{s as _};
