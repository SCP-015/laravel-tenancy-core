import{aq as o}from"./vue-vendor-kWKBmEf-.js";import{r}from"./utils-FrusicUM.js";const s=o(r());export{s as d};
